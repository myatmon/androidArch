package com.frontiir.arch.userarch.model;

/**
 * @author monshein
 * @since 1/16/18
 */

public class User {
    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    private String userId;

}
